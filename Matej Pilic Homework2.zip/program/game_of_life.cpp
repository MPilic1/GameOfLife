#include "game_of_life.h"
#include <cstdlib>
#include <ctime>

game_of_life::game_of_life() {
    srand(time(nullptr));
    for (unsigned int i = 0; i < ROWS; ++i) {
        for (unsigned int j = 0; j < COLS; ++j) {
            _generation[i][j] = random_value();
        }
    }
}

bool game_of_life::random_value() {
    return (rand() % 4 == 0);
}

bool game_of_life::cell_taken(int i, int j) {
    if (i < 0 || j < 0 || i >= ROWS || j >= COLS) {
        return false;
    }
    return _generation[i][j];
}

void game_of_life::next_generation() {
    for (unsigned int i = 0; i < ROWS; ++i) {
        for (unsigned int j = 0; j < COLS; ++j) {
            int alive_neighbors = 0;
            for (int di = -1; di <= 1; ++di) {
                for (int dj = -1; dj <= 1; ++dj) {
                    if (di == 0 && dj == 0) {
                        continue;
                    }
                    if (cell_taken(i + di, j + dj)) {
                        ++alive_neighbors;
                    }
                }
            }
            if (_generation[i][j]) {
                if (alive_neighbors < 2 || alive_neighbors > 3) {
                    _next_generation[i][j] = false;
                }
                else {
                    _next_generation[i][j] = true;
                }
            }
            else {
                if (alive_neighbors == 3) {
                    _next_generation[i][j] = true;
                }
                else {
                    _next_generation[i][j] = false;
                }
            }
        }
    }
    for (unsigned int i = 0; i < ROWS; ++i) {
        for (unsigned int j = 0; j < COLS; ++j) {
            _generation[i][j] = _next_generation[i][j];
        }
    }
}

void game_of_life::draw() {
    system("cls");
    for (unsigned int i = 0; i < ROWS; ++i) {
        for (unsigned int j = 0; j < COLS; ++j) {
            if (_generation[i][j]) {
                cout << "*";
            }
            else {
                cout << ".";
            }
        }
        cout << endl;
    }
}
